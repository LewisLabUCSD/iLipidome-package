## How to install

1. Download `iLipidome_0.1.0.tar.gz` file
2. Run `install.package("<filepath>", repos=NULL, type="source")` in R
3. Load the library with `library("iLipidome")`, and you are good to go!
